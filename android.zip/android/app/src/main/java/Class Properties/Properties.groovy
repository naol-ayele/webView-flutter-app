package Class Properties

class Properties {
}
